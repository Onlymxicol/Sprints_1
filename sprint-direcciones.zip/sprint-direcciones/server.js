const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const initSqlJs = require('sql.js');

const archivoBD = path.join(__dirname, 'envios.db');

initSqlJs().then(function (SQL) {
  let db;
  if (fs.existsSync(archivoBD)) {
    db = new SQL.Database(fs.readFileSync(archivoBD));
  } else {
    db = new SQL.Database();
  }

  db.run(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

  function guardarBD() {
    fs.writeFileSync(archivoBD, Buffer.from(db.export()));
  }

  guardarBD();

  const app = express();
  app.use(cors());
  app.use(express.json());
  app.use(express.static(path.join(__dirname, 'public')));

  app.post('/api/direcciones', function (req, res) {
    const clienteId = req.body.cliente_id;
    const ciudad = String(req.body.ciudad || '').trim();
    const direccion = String(req.body.direccion || '').trim();
    const telefono = String(req.body.telefono || '').trim();

    if (!clienteId || ciudad === '' || direccion === '' || telefono === '') {
      return res.status(400).json({ error: 'Todos los campos son obligatorios' });
    }

    if (!/^\d{10}$/.test(telefono)) {
      return res.status(400).json({ error: 'El teléfono debe tener 10 números' });
    }

    db.run(
      'INSERT INTO Direccion (cliente_id, ciudad, direccion, telefono) VALUES (?, ?, ?, ?)',
      [clienteId, ciudad, direccion, telefono]
    );

    const resultado = db.exec('SELECT last_insert_rowid()');
    const nuevoId = resultado[0].values[0][0];

    guardarBD();

    res.status(201).json({ id: nuevoId, mensaje: 'Dirección guardada correctamente' });
  });

  app.get('/api/direcciones', function (req, res) {
    const resultado = db.exec('SELECT id, cliente_id, ciudad, direccion, telefono FROM Direccion');
    const lista = [];

    if (resultado.length > 0) {
      const filas = resultado[0].values;
      for (let i = 0; i < filas.length; i++) {
        lista.push({
          id: filas[i][0],
          cliente_id: filas[i][1],
          ciudad: filas[i][2],
          direccion: filas[i][3],
          telefono: filas[i][4]
        });
      }
    }

    res.json(lista);
  });

  app.listen(3000, function () {
    console.log('Servidor listo en http://localhost:3000');
  });
});
